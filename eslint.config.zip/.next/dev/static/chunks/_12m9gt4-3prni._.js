(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__1fsccfeefcr1n._.css","static/chunks/node_modules_next_dist_20wefz_f1k6jn._.js","static/chunks/_10wt5_rr2rj0k._.js"],
    source: "entry"
});
